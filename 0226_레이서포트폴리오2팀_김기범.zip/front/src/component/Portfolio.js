import React from 'react';
import Education from './Education'

function Portfolio() {

  return (
    <div>
      <Education />
    </div>
  );
}

export default Portfolio;