import { React } from 'react';
import Portfolio from './Portfolio'

function Home(props) {

  return (
    <>
      <h1>home</h1>
      <Portfolio />
    </>
  );
}

export default Home;