import React from 'react';
import { Navbar, Nav } from 'react-bootstrap';
import { useHistory } from 'react-router-dom';

function NetworkInner() {
  let history = useHistory();
  
  return(
    <></>
  );

}

export default NetworkInner;