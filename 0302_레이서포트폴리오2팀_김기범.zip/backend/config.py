import os

class Config(object):
    JWT_SECRET_KEY = 'super_secret'