import os

class Config(object):
    JWT_SECRET_KEY = 'super_secret'
    GOOGLE_OAUTH_SECRET_KEY = 'google_super_secret'
    GOOGLE_CLIENT_ID = '181746160743-776h0kr7q74n5at88a429j2iopioo852.apps.googleusercontent.com'
    GOOGLE_CLIENT_SECRET = 'uUy88xEPULRUkzZ9CSYpuesD'
    GOOGLE_REDIRECT_URL = 'http://localhost:5000/auth/google/callback'